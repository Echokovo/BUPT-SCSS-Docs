import pathlib
import subprocess

def get_output(file):
    out = subprocess.check_output(['./bin/bplc', file])
    return out.decode().strip()

def check_output():
    data = pathlib.Path('test')
    for bplfile in data.glob('*.bpl'):
        output = get_output(bplfile)
        print(f'{"="*20}\n{bplfile.name}:\n{output}\n{"="*20}')
        path = f"./test/{bplfile.name.replace('.bpl', '')}.out"
        with open(path, 'w') as file:
            file.write(output)

if __name__ == "__main__":
    check_output()