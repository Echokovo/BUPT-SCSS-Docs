from pydantic import BaseModel


class RegisterRequest(BaseModel):
    user_name: str
    password: str

class LoginRequest(BaseModel):
    user_name: str
    password: str

class UploadHashRequest(BaseModel):
    c_hash: str
    k: str

class UploadPRequest(BaseModel):
    session_id: int
    file_name: str
    p: bytes

class UploadCRequest(BaseModel):
    session_id: int

class GetFileRequest(BaseModel):
    id: int

class GetKRequest(BaseModel):
    id: int