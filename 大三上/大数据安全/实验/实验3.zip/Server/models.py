from db import Base
from sqlalchemy import Column, Integer, String, LargeBinary, ForeignKey


class Users(Base):
    __tablename__ = "users"
    user_name = Column(String, index=True, primary_key=True)
    password = Column(String)

class Files(Base):
    __tablename__ = "files"
    file_hash = Column(String, index=True, primary_key=True)
    k = Column(String)
    challenge = Column(Integer)
    p = Column(LargeBinary, nullable=True)

class UserFiles(Base):
    __tablename__ = "user_files"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_name = Column(String, ForeignKey('users.user_name'))
    file_name = Column(String)
    file_hash = Column(String)

class Sessions(Base):
    __tablename__ = "sessions"
    session_id = Column(Integer, primary_key=True, autoincrement=True)
    user_name = Column(String, ForeignKey('users.user_name'))
    file_hash = Column(String)
    state = Column(Integer, default=0)