import os
from random import randint
from fastapi import APIRouter, Depends, HTTPException, UploadFile, Form, File
from sqlalchemy.orm import Session

from crud import get_file_by_hash, create_session, create_file, get_session_by_session_id, create_user_files, \
    create_user, get_user_by_name, get_user_files_by_user_name, get_user_files_by_id
from db import get_db
from schemas import RegisterRequest, UploadHashRequest, UploadPRequest, UploadCRequest, GetFileRequest, GetKRequest
from utils import get_current_user
from fastapi.responses import FileResponse

router = APIRouter(prefix="/api")

@router.post("/Register")
def register(register_request: RegisterRequest, db: Session = Depends(get_db)):
    user_name = register_request.user_name
    password = register_request.password

    user = get_user_by_name(db, user_name)
    if user:
        raise HTTPException(status_code=409 , detail="User already exists")
    user = create_user(db, user_name, password)
    return {"message": "Success"}

@router.post("/Upload_Hash")
def upload_hash(upload_hash_request: UploadHashRequest, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    c_hash = upload_hash_request.c_hash
    k = upload_hash_request.k
    print(f"{c_hash=} {k=}")
    file = get_file_by_hash(db, c_hash)
    session = create_session(db, current_user.user_name, c_hash)
    if file is None:
        challenge = randint(1000, 9999)
        file = create_file(db, c_hash, k, challenge)
        session.state = 0
        print("state = 0")
    else:
        challenge = file.challenge
        session.state = 1
        print("state = 1")
    db.commit()
    return {"session_id": session.session_id, "challenge": challenge}

@router.post("/Upload_P")
def upload_p(upload_p_request: UploadPRequest, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    session_id = upload_p_request.session_id
    file_name = upload_p_request.file_name
    p = upload_p_request.p
    print(f"{session_id=} {file_name=} {p=}")
    session = get_session_by_session_id(db, session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    if session.state == 0:
        file_hash = session.file_hash
        file = get_file_by_hash(db, file_hash)
        file.p = p
        session.state = 2
        db.commit()
        return {"message": "Upload now"}
    else:
        file_hash = session.file_hash
        file = get_file_by_hash(db, file_hash)
        if file.p == p:
            user_file = create_user_files(db, current_user.user_name, file_name, session.file_hash)
            # 验证成功 创建链接
            return {"message": "File exists"}
        else:
            raise HTTPException(status_code=400, detail="Bad P")
            # 用户上传的 P 与存储的 P 不同

@router.post("/Upload_C")
def upload_c(session_id: int = Form(), c: UploadFile = File(), db: Session = Depends(get_db)):
    file_name = c.filename
    c = c.file.read()
    print(f"{file_name=} {c=}")
    session = get_session_by_session_id(db, session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.state != 2:
        return {"message": "Error state"}
    user_file = create_user_files(db, session.user_name, file_name, session.file_hash)
    path = os.path.join(os.getcwd(), "Files", session.file_hash)
    with open(path, "wb") as f:
        f.write(c)
    return {"message": "Success"}

@router.post("/Get_File_List")
def get_file_list(db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    files = get_user_files_by_user_name(db, current_user.user_name)
    return {"data": [(x.id, x.file_name) for x in files]}

@router.post("/Get_File")
def get_file(get_file_request: GetFileRequest, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    id = get_file_request.id
    user_files = get_user_files_by_id(db, id)
    if user_files is None:
        raise HTTPException(status_code=404, detail="File not found")
    if user_files.user_name != current_user.user_name:
        raise HTTPException(status_code=404, detail="File not found")
    file = get_file_by_hash(db, user_files.file_hash)
    path = os.path.join(os.getcwd(), "Files", user_files.file_hash)
    return FileResponse(path)

@router.post("/Get_K")
def get_k(get_k_request: GetKRequest, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    id = get_k_request.id
    user_files = get_user_files_by_id(db, id)
    if user_files is None:
        raise HTTPException(status_code=404, detail="File not found")
    if user_files.user_name != current_user.user_name:
        raise HTTPException(status_code=404, detail="File not found")
    file = get_file_by_hash(db, user_files.file_hash)
    return {"file_name": user_files.file_name, "k": file.k}
