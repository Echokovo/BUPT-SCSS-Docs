from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

engine = create_engine("sqlite:///database.db")
DBSession = sessionmaker(bind=engine)
Base = declarative_base()

def get_db():
    db = DBSession()
    try:
        yield db
    finally:
        db.close()