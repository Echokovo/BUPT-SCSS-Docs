from typing import List

from models import Users, Files, UserFiles, Sessions


def create_user(db, user_name, password) -> Users:
    user = Users(user_name = user_name, password = password)
    db.add(user)
    db.commit()
    return user

def get_user_by_name(db, user_name) -> Users:
    return db.query(Users).filter(Users.user_name == user_name).first()

def create_file(db, file_hash, k, challenge) -> Files:
    file = Files(file_hash = file_hash, k = k, challenge = challenge)
    db.add(file)
    db.commit()
    return file

def get_file_by_hash(db, file_hash) -> Files:
    return db.query(Files).filter(Files.file_hash == file_hash).first()

def create_user_files(db, user_name, file_name, file_hash) -> UserFiles:
    user_files = UserFiles(user_name = user_name, file_name = file_name, file_hash = file_hash)
    db.add(user_files)
    db.commit()
    return user_files

def get_user_files_by_user_name(db, user_name) -> List[UserFiles]:
    return db.query(UserFiles).filter(UserFiles.user_name == user_name).all()

def get_user_files_by_id(db, id) -> UserFiles:
    return db.query(UserFiles).filter(UserFiles.id == id).first()

def create_session(db, user_name, file_hash) -> Sessions:
    session = Sessions(user_name = user_name, file_hash = file_hash)
    db.add(session)
    db.commit()
    return session

def get_session_by_session_id(db, session_id) -> Sessions:
    return db.query(Sessions).filter(Sessions.session_id == session_id).first()