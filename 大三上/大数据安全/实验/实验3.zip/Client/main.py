import inquirer
from Utils import auth, file_ops


def main():
    print("\033c", end="")
    current_user_token = None

    print("=" * 40)
    print("欢迎使用邮盘客户端")
    print("=" * 40)

    while True:
        # 根据用户是否登录，动态生成菜单
        if current_user_token is None:
            main_menu_choices = [
                '注册',
                '登录',
                '退出'
            ]
        else:
            main_menu_choices = [
                '上传文件',
                '查询文件',
                '下载文件',
                '注销登录',
                '退出'
            ]

        questions = [
            inquirer.List(
                'action',
                message="请选择操作",
                choices=main_menu_choices,
            ),
        ]

        answers = inquirer.prompt(questions)

        # 如果用户直接回车或按Ctrl+C退出选择，answers会是None
        if not answers:
            print("\n感谢使用，再见！")
            break

        action = answers['action']

        if action == '注册':
            token = auth.register()
            if token:
                current_user_token = token
                print(f"用户已注册，令牌已保存。")
        elif action == '登录':
            # 登录成功后，会返回一个令牌
            token = auth.login()
            if token:
                current_user_token = token
                print(f"用户已登录，令牌已保存。")
        elif action == '上传文件':
            # 确保用户已登录
            if current_user_token:
                file_ops.upload_file(current_user_token)
            else:
                print("错误：请先登录！")
        elif action == '查询文件':
            if current_user_token:
                file_ops.query_files(current_user_token)
            else:
                print("错误：请先登录！")
        elif action == '下载文件':
            if current_user_token:
                file_ops.download_files(current_user_token)
            else:
                print("错误：请先登录！")
        elif action == '注销登录':
            current_user_token = None
            print("已成功注销登录。")
        elif action == '退出':
            print("感谢使用，再见！")
            break

        # 在每次操作后添加一个暂停，让用户看清结果
        if action != '退出':
            input("\n按 Enter 键返回主菜单...")
            print("\033c", end="")  # 清屏（在Windows/macOS/Linux大部分终端中有效）


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n程序被用户中断。感谢使用，再见！")