import base64
import hashlib
import os
import random
import inquirer
from pathlib import Path

import requests
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

URL = "http://127.0.0.1:8000"
K_USER = "01234567890123456789012345678901"

def upload_file(auth_token):
    print("\n--- 上传文件 ---")
    print(f"当前认证令牌: {auth_token}")
    path = os.path.join(os.getcwd(), "Files")
    upload_dir = Path(path)
    if not upload_dir.is_dir():
        print(f"错误：目录 '{upload_dir}' 不存在。请创建该目录并放入文件后重试。")
        return False
    files = [f for f in upload_dir.iterdir() if f.is_file()]
    if not files:
        print(f"错误：目录 '{upload_dir}' 中没有可上传的文件。")
        return False
    questions = [
        inquirer.List(
            'selected_file',
            message="请选择要上传的文件",
            choices=[(f.name, f) for f in files]
        )
    ]
    answers = inquirer.prompt(questions)
    if not answers:
        print("操作取消。")
        return False
    selected_file_path = answers['selected_file']
    print(f"\n准备上传文件: {selected_file_path.name}")
    print(f"文件大小: {selected_file_path.stat().st_size} bytes")

    user_name = auth_token[0]
    password = auth_token[1]
    file_name = selected_file_path.name
    file_path = os.path.join(path, file_name)
    with open(file_path, 'rb') as f:
        file = f.read()
    c_key = hashlib.sha256(file).digest()
    c_cipher = AES.new(c_key, AES.MODE_ECB)
    c = c_cipher.encrypt(pad(file, AES.block_size))
    c_hash = hashlib.sha256(c).hexdigest()
    k_cipher = AES.new(K_USER.encode(), AES.MODE_ECB)
    k = k_cipher.encrypt(pad(c_key, AES.block_size))
    k_base64 = base64.b64encode(k).decode()
    response = requests.post(URL + "/api/Upload_Hash", json = {
        "upload_hash_request": {
            "c_hash": c_hash,
            "k": k_base64
        },
        "login_request": {
            "user_name": user_name,
            "password": password
        }
    })
    try:
        session_id = response.json()["session_id"]
        challenge = response.json()["challenge"]
    except Exception as e:
        print("Error in Upload_Hash")
        print(e)
        return False
    random.seed(challenge)
    p = ""
    for _ in range(32):
        p += chr(random.choice(file))
    print(f"P: {p}")
    response = requests.post(URL + "/api/Upload_P", json = {
        "upload_p_request": {
            "session_id": session_id,
            "file_name": file_name,
            "p": p
        },
        "login_request": {
            "user_name": user_name,
            "password": password
        }
    })

    if response.json().get("message") not in ["Upload now", "File exists"]:
        print("Error in Upload_P")
        print(response.json())
        return False

    if response.json().get("message") == "Upload now":
        print("判定为新文件\n现在上传文件")
        data = {
            "session_id": session_id
        }
        response = requests.post(URL + "/api/Upload_C", data = data, files={
            "c": (file_name, c)
        })
        if response.json().get("message") != "Success":
            print("Error in Upload_C")
            print(response.json())
            return False
    else:
        print("判断为重复文件\n无需上传文件")
        return True
    return True


def query_files(auth_token):
    print("\n--- 查询文件 ---")
    print(f"当前认证令牌: {auth_token}")
    print("正在向服务器请求文件列表...")
    user_name = auth_token[0]
    password = auth_token[1]
    response = requests.post(URL + "/api/Get_File_List", json = {
        "user_name": user_name,
        "password": password
    })
    if response.status_code != 200:
        print("Error in Get_File_List")
        print(response.json())
        return False
    try:
        datas = response.json().get("data")
        if len(datas) == 0:
            print("No files found in 邮盘")
            return True
        print("  id    文件名")
        for i, data in datas:
            print(f"{i:4}    {data:10}")
    except Exception as e:
        print("Error in Get_File_List")
        print(e)
        return False
    return True

def download_files(auth_token):
    print("\n--- 下载文件 ---")
    id = input("请输入文件id：")
    user_name = auth_token[0]
    password = auth_token[1]
    response = requests.post(URL + "/api/Get_K", json = {
        "get_k_request": {
            "id": id
        },
        "login_request": {
            "user_name": user_name,
            "password": password
        }
    })
    if response.status_code != 200:
        print("Error in Get_K")
        print(response.json())
        return False
    try:
        file_name = response.json().get("file_name")
        k_base64 = response.json().get("k")
        k = base64.b64decode(k_base64)
    except Exception as e:
        print("Error in Get_K")
        print(e)
        return False
    response = requests.post(URL + "/api/Get_File", json = {
        "get_file_request": {
            "id": id
        },
        "login_request": {
            "user_name": user_name,
            "password": password
        }
    })
    if response.status_code != 200:
        print("Error in Get_File")
        print(response.json())
        return False
    try:
        k_cipher = AES.new(K_USER.encode(), AES.MODE_ECB)
        c_key = unpad(k_cipher.decrypt(k), AES.block_size)
        c_cipher = AES.new(c_key, AES.MODE_ECB)
        file = unpad(c_cipher.decrypt(response.content), AES.block_size)
        path = os.path.join(os.getcwd(), "Downloads", file_name)
        with open(path, "wb") as f:
            f.write(file)
        print(f"文件已保存至 {path}")
    except Exception as e:
        print("Error in Get_File")
        print(e)
        return False
    return True