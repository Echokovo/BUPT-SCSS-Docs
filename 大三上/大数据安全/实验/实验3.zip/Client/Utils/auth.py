import inquirer
import requests

URL = "http://127.0.0.1:8000"

def register():
    print("\n--- 用户注册 ---")
    questions = [
        inquirer.Text('username', message="请输入用户名"),
        inquirer.Text('password', message="请输入密码")
    ]
    answers = inquirer.prompt(questions)
    if not answers:
        print("操作取消。")
        return False
    username = answers['username']
    password = answers['password']
    response = requests.post(URL + "/api/Register", json={'user_name': username, 'password': password})
    if response.json().get("message") == "Success":
        return username, password
    print("注册失败")
    print(response.json())
    return False

def login():
    print("\n--- 用户登录 ---")
    questions = [
        inquirer.Text('username', message="请输入用户名"),
        inquirer.Text('password', message="请输入密码")
    ]
    answers = inquirer.prompt(questions)
    if not answers:
        print("操作取消。")
        return False
    username = answers['username']
    password = answers['password']
    return username, password