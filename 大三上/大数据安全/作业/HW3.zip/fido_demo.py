from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
import json
from fido2.server import Fido2Server
from fido2.webauthn import PublicKeyCredentialRpEntity, PublicKeyCredentialUserEntity, AttestedCredentialData
import secrets

app = FastAPI(title="FIDO2 Demo")

templates = Jinja2Templates(directory="templates")

# users: username -> {id, username, display_name, user_handle}
users = {}
user_id_seq = 1

# stored_credentials -> {id, username, credential}
stored_credentials = []
credential_id_seq = 1

rp = PublicKeyCredentialRpEntity(id="bupt-bingo.online", name="FIDO2 Demo")
fido2_server = Fido2Server(rp)

registration_sessions = {}
authentication_sessions = {}

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """主页面"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/api/register/start")
async def register_start(request: Request, username: str = Form(...), display_name: str = Form(...)):
    """开始注册流程"""
    global user_id_seq, users
    if username in users:
        raise HTTPException(status_code=400, detail="用户已存在")
    user_handle = secrets.token_bytes(16)
    users[username] = {
        "id": user_id_seq,
        "username": username,
        "display_name": display_name,
        "user_handle": user_handle
    }
    user_id_seq += 1
    user = PublicKeyCredentialUserEntity(
        id=user_handle,
        name=username,
        display_name=display_name
    )
    options, state = fido2_server.register_begin(
        user,
        credentials=[],
        user_verification="discouraged",
        authenticator_attachment="platform"
    )
    session_id = secrets.token_hex(16)
    registration_sessions[session_id] = {
        "state": state,
        "username": username
    }
    return JSONResponse({
        "session_id": session_id,
        "options": dict(options)
    })

@app.post("/api/register/complete")
async def register_complete(session_id: str = Form(...), credential: str = Form(...)):
    """完成注册流程"""
    if session_id not in registration_sessions:
        raise HTTPException(status_code=400, detail="会话无效或已过期")
    session_data = registration_sessions[session_id]
    state = session_data["state"]
    username = session_data["username"]
    
    try:
        credential_json = json.loads(credential)
        auth_data = fido2_server.register_complete(state, credential_json)
        global credential_id_seq, stored_credentials
        credential = auth_data.credential_data

        stored_credentials.append({
            "id": credential_id_seq,
            "username": username,
            "credential": credential
        })
        credential_id_seq += 1

        del registration_sessions[session_id]

        return JSONResponse({"status": "success", "message": "注册成功"})

    except Exception as e:
        # 如果注册失败，删除用户
        registration_sessions.pop(session_id, None)
        users.pop(username, None)
        raise HTTPException(status_code=400, detail=f"注册失败: {str(e)}")

@app.post("/api/authenticate/start")
async def authenticate_start(request: Request, username: str = Form(...)):
    """开始认证流程"""
    if username not in users:
        raise HTTPException(status_code=400, detail="用户不存在")
    credentials = []
    for cred in stored_credentials:
        if cred.get("username") != username:
            continue
        credential = cred.get("credential")
        credentials.append(credential)
    
    if not credentials:
        raise HTTPException(status_code=400, detail="用户没有注册的凭据")
    options, state = fido2_server.authenticate_begin(credentials)
    session_id = secrets.token_hex(16)
    authentication_sessions[session_id] = {
        "state": state,
        "username": username
    }

    return JSONResponse({
        "session_id": session_id,
        "options": dict(options)
    })

@app.post("/api/authenticate/complete")
async def authenticate_complete(session_id: str = Form(...), credential: str = Form(...)):
    """完成认证流程"""
    if session_id not in authentication_sessions:
        raise HTTPException(status_code=400, detail="会话无效或已过期")
    
    session_data = authentication_sessions[session_id]
    state = session_data["state"]
    username = session_data["username"]
    
    try:
        credential_json = json.loads(credential)
        credentials = []
        for cred in stored_credentials:
            if cred.get("username") != username:
                continue
            credential = cred.get("credential")
            credentials.append(credential)
        fido2_server.authenticate_complete(state, credentials, credential_json)

        # 清理会话
        del authentication_sessions[session_id]

        return JSONResponse({
            "status": "success",
            "message": f"认证成功！欢迎 {username}"
        })

    except Exception as e:
        raise HTTPException(status_code=400, detail=f"认证失败: {str(e)}")

@app.get("/api/users")
async def get_users():
    """获取所有用户（用于测试）"""
    out = [{"id": u["id"], "username": u["username"], "display_name": u["display_name"]} for u in users.values()]
    return JSONResponse(out)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=443, ssl_certfile="/etc/ssl/bupt-bingo.online.pem", ssl_keyfile="/etc/ssl/bupt-bingo.online.key")