
int main(int argc, char *argv[]) {
HANDLE hp;
HLOCAL h1, h2, h3, h4, h5, h6, h7, h8, h9;

hp = HeapCreate(0,0x1000,0x10000);
h1 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 16);
memset(h1, 'a', 16);
h2 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 16);
memset(h2, 'b', 16);
h3 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 32);
memset(h3, 'c', 32);
h4 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 16);
memset(h4, 'd', 16);
h5 = HeapAlloc(hp, HEAP_ZERO_MEMORY,8)
memset(h5, 'e', 8);
HeapFree(hp, 0, h2); 
HeapFree(hp, 0, h3);
HeapFree(hp, 0, h3);
h6 = HeapAlloc(hp, 0, 64);
memset(h6, 'f', 64);
strcpy((char *)h4, buffer);
h7 = HeapAlloc(hp, 0, 16);
printf("Never gets here.\n”);
}
